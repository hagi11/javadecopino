/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexion;

/**
 *
 * @author USUARIO
 */
public interface Configuracion {

//    String DRIVER = "oracle.jdbc.driver.OracleDriver";
//    String CONNECTION_URL = "jdbc:oracle:thin:@localhost:1521:xe";
//    String USERNAME = "system";
//    String PASSWORD = "oracle";
    
//    String DRIVER = "com.mysql.jdbc.Driver";
//    String DATA_BASE = "softclotech_ADSI192_prueba";   
//    String CONNECTION_URL = "jdbc:mysql://34.95.206.133:3306/"+DATA_BASE;
//    String USERNAME = "softclotech_invitadoadsi192";
//    String PASSWORD = "Adsi192invitado";
    
//    String DRIVER = "com.mysql.jdbc.Driver";
//    String DATA_BASE = "yobusco_165-Adsi";
//    String CONNECTION_URL = "jdbc:mysql://158.85.67.158:3306/"+DATA_BASE;    
//    String USERNAME = "yobusco_165-invi";
//    String PASSWORD = "adsi1234567*165";
    
//    String DRIVER = "org.postgresql.Driver";
//    String DATA_BASE = "postgres";
//    String CONNECTION_URL = "jdbc:postgresql://localhost:5432/"+DATA_BASE;    
//    String USERNAME = "postgres";
//    String PASSWORD = "jaime";
//    
//    String DRIVER = "org.apache.derby.jdbc.ClientDriver";
//    String DATA_BASE = "agenda";
//    String CONNECTION_URL = "jdbc:derby://localhost:1527/"+DATA_BASE;    
//    String USERNAME = "agenda";
//    String PASSWORD = "agenda";
    
//    String DRIVER = "com.mysql.jdbc.Driver";
//    String DATA_BASE = "decoraci_decopino";
//    String CONNECTION_URL = "jdbc:mysql://localhost:3306/"+DATA_BASE;    
//    String USERNAME = "root";
//    String PASSWORD = "";
    
    String DRIVER = "com.mysql.cj.jdbc.Driver";
    String DATA_BASE = "decoraci_decopino";
//    String CONNECTION_URL = "jdbc:mysql://decoracioneslospinos.com:3306/" + DATA_BASE + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    String CONNECTION_URL = "jdbc:mysql://decoracioneslospinos.com:3306/"+DATA_BASE;
    String USERNAME = "decoraci_adsi200";
    String PASSWORD = "los20pinos";
}
